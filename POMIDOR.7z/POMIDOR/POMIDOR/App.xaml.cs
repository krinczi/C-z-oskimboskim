﻿using System.Windows;

namespace POMIDOR;

public partial class App : Application
{
}
