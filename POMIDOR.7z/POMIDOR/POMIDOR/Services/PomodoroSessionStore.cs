﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text.Json;
using POMIDOR.Models;

namespace POMIDOR.Services
{
    public static class PomodoroSessionStore
    {
        private static readonly JsonSerializerOptions _opts = new()
        {
            WriteIndented = true,
            PropertyNamingPolicy = JsonNamingPolicy.CamelCase
        };

        public static List<PomodoroSession> LoadAll()
        {
            try
            {
                if (!File.Exists(AppPaths.PomodoroSessionsFile))
                    return new List<PomodoroSession>();

                var json = File.ReadAllText(AppPaths.PomodoroSessionsFile);
                return JsonSerializer.Deserialize<List<PomodoroSession>>(json, _opts) ?? new List<PomodoroSession>();
            }
            catch
            {
                return new List<PomodoroSession>();
            }
        }

        public static void Append(PomodoroSession session)
        {
            var list = LoadAll();
            list.Add(session);
            SaveAll(list);
        }

        public static void SaveAll(List<PomodoroSession> list)
        {
            Directory.CreateDirectory(Path.GetDirectoryName(AppPaths.PomodoroSessionsFile)!);
            var json = JsonSerializer.Serialize(list.OrderBy(x => x.StartUtc).ToList(), _opts);
            File.WriteAllText(AppPaths.PomodoroSessionsFile, json);
        }
    }
}
