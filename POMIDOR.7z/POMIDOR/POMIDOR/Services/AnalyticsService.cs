﻿using System;
using System.Collections.Generic;
using System.Linq;
using POMIDOR.Models;

namespace POMIDOR.Services
{
    public sealed class AnalyticsService
    {
        public StatsResult Compute(
            IEnumerable<TodoItem> tasks,
            IEnumerable<GoalItem> goals,
            IEnumerable<PomodoroSession> sessions,
            ReportKind kind,
            DateTime anchorLocal)
        {
            var period = ReportPeriod.For(kind, anchorLocal);

            // Zadania "w okresie": filtrujemy po Due ∈ [Start, End] (jeśli brak CompletedAt)
            var inPeriod = tasks.Where(t => t.Due.HasValue && period.Contains(t.Due.Value)).ToList();

            // Ukończone zadania w okresie (wg Due)
            var completedInPeriod = inPeriod.Where(t => t.IsCompleted).ToList();

            // Ukończone subtaski w okresie: bierzemy subtaski z zadań posiadających Due w okresie
            // i liczymy te oznaczone jako done
            var completedSubs = inPeriod
                .SelectMany(t => t.SubTasks ?? Enumerable.Empty<SubTask>())
                .Count(st => st.IsCompleted);

            // Czas Pomodoro: sesje zakończone w okresie
            var pomoMinutes = sessions
                .Where(s => s.EndUtc.ToLocalTime() >= period.Start && s.EndUtc.ToLocalTime() <= period.End)
                .Sum(s => s.DurationMinutes);

            // Zaległe: brak ukończenia i Due < koniec okresu
            var overdue = tasks
                .Where(t => !t.IsCompleted && t.Due.HasValue && t.Due.Value.Date < period.End.Date)
                .Count();

            // % realizacji celów: zadania z niepustym Goal (string), Due w okresie
            var tasksWithGoalsInPeriod = inPeriod
                .Where(t => !string.IsNullOrWhiteSpace(t.Goal))
                .ToList();

            double goalsPct = 0;
            if (tasksWithGoalsInPeriod.Count > 0)
            {
                var grouped = tasksWithGoalsInPeriod
                    .GroupBy(t => t.Goal!.Trim())
                    .Select(g =>
                    {
                        var total = g.Count();                // UWAGA: Count()
                        var done = g.Count(t => t.IsCompleted);
                        return (total, done);
                    }).ToList();

                var totalAll = grouped.Sum(x => x.total);
                var doneAll = grouped.Sum(x => x.done);
                goalsPct = totalAll == 0 ? 0 : (double)doneAll / totalAll * 100.0;
            }

            // Historia dzienna po DUE (brak CompletedAt)
            var days = Enumerable.Range(0, (period.End.Date - period.Start.Date).Days + 1)
                                 .Select(i => period.Start.Date.AddDays(i))
                                 .ToList();

            var completedPerDay = completedInPeriod
                .Where(t => t.Due.HasValue)
                .GroupBy(t => t.Due!.Value.Date)
                .ToDictionary(g => g.Key, g => g.Count());

            var pomoPerDay = sessions
                .Where(s => s.EndUtc.ToLocalTime() >= period.Start && s.EndUtc.ToLocalTime() <= period.End)
                .GroupBy(s => s.EndUtc.ToLocalTime().Date)
                .ToDictionary(g => g.Key, g => g.Sum(x => x.DurationMinutes));

            var series = days.Select(d => new DayPoint
            {
                Day = d,
                CompletedTasks = completedPerDay.TryGetValue(d, out var c) ? c : 0,
                PomodoroMinutes = pomoPerDay.TryGetValue(d, out var p) ? p : 0
            }).ToList();

            return new StatsResult
            {
                Kind = kind,
                Period = period,
                CompletedTasks = completedInPeriod.Count,
                CompletedSubTasks = completedSubs,
                GoalsCompletionPct = Math.Round(goalsPct, 1),
                PomodoroMinutes = pomoMinutes,
                OverdueTasks = overdue,
                TimeSeries = series
            };
        }
    }
}
