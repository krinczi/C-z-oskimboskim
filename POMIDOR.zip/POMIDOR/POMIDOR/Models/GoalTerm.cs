﻿namespace POMIDOR.Models;

public enum GoalTerm
{
    ShortTerm,
    LongTerm
}
