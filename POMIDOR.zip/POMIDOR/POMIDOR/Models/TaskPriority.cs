﻿namespace POMIDOR.Models;

public enum TaskPriority
{
    Low,
    Normal,
    High
}
