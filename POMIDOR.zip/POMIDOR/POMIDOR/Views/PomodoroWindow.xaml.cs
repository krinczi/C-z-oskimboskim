﻿using System;
using System.Media;
using System.Windows;
using System.Windows.Threading;
using POMIDOR.Models;

namespace POMIDOR.Views;

public partial class PomodoroWindow : Window
{
    private enum PomodoroPhase { Idle, Work, Break }

    private readonly DispatcherTimer _timer = new DispatcherTimer { Interval = TimeSpan.FromSeconds(1) };
    private PomodoroPhase _phase = PomodoroPhase.Idle;
    private TimeSpan _remaining;
    private TimeSpan _workDur = TimeSpan.FromMinutes(25);
    private TimeSpan _breakDur = TimeSpan.FromMinutes(5);

    private PomodoroStats _stats = new PomodoroStats();

    public PomodoroWindow()
    {
        InitializeComponent();
        _timer.Tick += Timer_Tick;
        LoadStats();
        RefreshStatsUi();
        SetPhase(PomodoroPhase.Idle, resetTime: true);
    }

    private void LoadStats()
    {
        _stats = PomodoroStore.Load();
    }
    private void SaveStats()
    {
        _stats.LastUpdated = DateTime.UtcNow;
        PomodoroStore.Save(_stats);
        RefreshStatsUi();
    }

    private void RefreshStatsUi()
    {
        CyclesText.Text = _stats.CompletedCycles.ToString();
        TotalWorkText.Text = TimeSpan.FromSeconds(_stats.TotalWorkSeconds).ToString(@"hh\:mm\:ss");
        TotalBreakText.Text = TimeSpan.FromSeconds(_stats.TotalBreakSeconds).ToString(@"hh\:mm\:ss");
    }

    private void Timer_Tick(object? sender, EventArgs e)
    {
        if (_remaining > TimeSpan.Zero)
        {
            _remaining -= TimeSpan.FromSeconds(1);
            UpdateTimerLabel();
            return;
        }

        // czas minął
        _timer.Stop();
        if (SoundBox.IsChecked == true)
            SystemSounds.Exclamation.Play();

        if (_phase == PomodoroPhase.Work)
        {
            _stats.CompletedCycles += 1;
            _stats.TotalWorkSeconds += (long)_workDur.TotalSeconds;
            SaveStats();
        }
        else if (_phase == PomodoroPhase.Break)
        {
            _stats.TotalBreakSeconds += (long)_breakDur.TotalSeconds;
            SaveStats();
        }

        if (AutoSwitchBox.IsChecked == true)
        {
            if (_phase == PomodoroPhase.Work)
                StartBreak();
            else if (_phase == PomodoroPhase.Break)
                StartWork();
        }
        else
        {
            SetPhase(PomodoroPhase.Idle, resetTime: true);
        }
    }

    private void UpdateTimerLabel()
    {
        TimerLabel.Text = _remaining.ToString(@"mm\:ss");
    }

    private void SetPhase(PomodoroPhase phase, bool resetTime)
    {
        _phase = phase;

        switch (phase)
        {
            case PomodoroPhase.Idle:
                PhaseLabel.Text = "Tryb: bezczynny";
                if (resetTime) { _remaining = _workDur; UpdateTimerLabel(); }
                break;
            case PomodoroPhase.Work:
                PhaseLabel.Text = "Tryb: PRACA";
                if (resetTime) { _remaining = _workDur; UpdateTimerLabel(); }
                break;
            case PomodoroPhase.Break:
                PhaseLabel.Text = "Tryb: PRZERWA";
                if (resetTime) { _remaining = _breakDur; UpdateTimerLabel(); }
                break;
        }
    }

    private bool TryReadDurations()
    {
        if (!int.TryParse(WorkBox.Text.Trim(), out var w) || w <= 0) return false;
        if (!int.TryParse(BreakBox.Text.Trim(), out var b) || b <= 0) return false;
        _workDur = TimeSpan.FromMinutes(w);
        _breakDur = TimeSpan.FromMinutes(b);
        return true;
    }

    private void StartWork()
    {
        if (!TryReadDurations())
        {
            MessageBox.Show("Podaj poprawne minuty dla PRACY i PRZERWY.", "Pomodoro", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }
        SetPhase(PomodoroPhase.Work, resetTime: true);
        _timer.Start();
    }

    private void StartBreak()
    {
        if (!TryReadDurations()) return;
        SetPhase(PomodoroPhase.Break, resetTime: true);
        _timer.Start();
    }

    private void Start_Click(object sender, RoutedEventArgs e)
    {
        if (!TryReadDurations())
        {
            MessageBox.Show("Podaj poprawne minuty.", "Pomodoro", MessageBoxButton.OK, MessageBoxImage.Warning);
            return;
        }

        if (_phase == PomodoroPhase.Idle)
            SetPhase(PomodoroPhase.Work, resetTime: true);

        _timer.Start();
    }

    private void Pause_Click(object sender, RoutedEventArgs e)
    {
        _timer.Stop();
    }

    private void Reset_Click(object sender, RoutedEventArgs e)
    {
        _timer.Stop();
        if (!TryReadDurations()) return;
        SetPhase(PomodoroPhase.Idle, resetTime: true);
    }
}
